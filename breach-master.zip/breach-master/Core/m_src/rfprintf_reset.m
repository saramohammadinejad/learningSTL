function rfprintf_reset()
  
  global st__;
  st__ = '';
