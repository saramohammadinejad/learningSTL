% Copyright (c) 2008-2016 MonkeyProof Solutions B.V.
% Use is subject to the MIT license

classdef Customizer < Customizer
    
    methods (Static)
        
        % Customizing Methods
        schema      = makeConstantsOrange(callbackInfo)
        
    end
    
end
