classdef Customizer < Customizer
    
    methods (Static)
        
        % Customizing Methods
        schema      = createBreachSystem(callbackInfo)
        
    end
    
end
